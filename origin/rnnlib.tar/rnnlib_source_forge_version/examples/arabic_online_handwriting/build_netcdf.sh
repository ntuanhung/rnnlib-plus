#! /bin/bash
./arabic_online.py filenames.txt arabic_online.nc
